# Privacy Policy - Bharat Map Puzzle
Last updated: <DATE>

Bharat Map Puzzle does not require an account and does not collect, sell or share personal information.
Game progress (score, XP, coins, settings) is stored only on your device and is deleted when you clear app data or uninstall.
The app may load fonts from Google Fonts, which can receive your IP address as part of a normal web request.
If advertising is added in a future version, this policy will be updated before release.
Contact: <YOUR EMAIL>
