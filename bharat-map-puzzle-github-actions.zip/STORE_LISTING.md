Title (max 30): Bharat Map Puzzle
Short description (max 80): India geography puzzle: states, capitals, borders. Can you master India?
Category: Games > Puzzle (or Education). Target audience: 13+ (avoids Designed-for-Families rules).
Needed: 512x512 icon, 1024x500 feature graphic, 2-8 phone screenshots, privacy policy URL (host PRIVACY_POLICY.md on a public page).
