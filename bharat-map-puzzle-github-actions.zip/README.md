# Bharat Map Puzzle - cloud AAB build (no Android Studio needed)

1. Create a PRIVATE GitHub repo and upload everything from this zip (keep the .github folder).
2. Edit capacitor.config.json: change appId (com.CHANGEME.bharatmap) to your own. Cannot be changed after publishing.
3. Actions tab > "1 - Create upload keystore (run once)" > Run. Download artifact "keystore-secrets-BACKUP-THIS".
   BACK UP upload.jks + keystore-secrets.txt somewhere safe, then delete the artifact.
4. Repo Settings > Secrets and variables > Actions > New secret. Add the 4 values from keystore-secrets.txt:
   ANDROID_KEYSTORE_BASE64, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD
5. Actions tab > "2 - Build signed Android AAB" > Run. Download artifact "bharat-map-puzzle-signed-aab":
   app-release.aab -> upload to Play Console | app-debug.apk -> install on your phone to test first.
   Every run auto-increases versionCode, so each AAB can be uploaded as a new release.
6. Play Console: closed testing track -> upload the AAB. See STORE_LISTING.md and PRIVACY_POLICY.md. store/icon-512.png is a placeholder store icon.

Local build instead: Node 22+, JDK 21, Android Studio; npm install; npx cap add android; copy res/mipmap-* into android/app/src/main/res; npx cap sync; Build > Generate Signed Bundle.
